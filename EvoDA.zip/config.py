
# 数据集特异性的配置文件

def load_config(dataset):

    config = None
    if dataset == "SEED":
        config = SEED_config
    elif dataset == "SEED5":
        config = SEED5_config
    elif dataset == "MPED":
        config = MPED_config
    else:
        raise Exception("Wrong dataset!")

    return config



SEED_config = {
    "dataset_name": "SEED",
    "num_class": 3,
    "head_size": 6,
    "n_qry": 5,
    "subject_num": 15,
    "epsilon": 0.1,  # 0.14
    "eeg_node_num": 62,
    "input_size": 5,
    "batch_size": 30,
    "loca_size": 3,
    "expand_size": 10,   # attention feature expend size
    "data_path": "/data2/Ming/SEED/FSL/4s/",
    "shots": 1
}

SEED5_config = {
    "dataset_name": "SEED5",
    "session": 1,
    "head_size": 6,
    "n_qry": 5,
    "subject_num": 16,
    "num_class": 5,
    "epsilon": 0.08,  # 0.08
    "eeg_node_num": 62,
    "batch_size": 30,
    "input_size": 5,
    "loca_size": 3,
    "expand_size": 10,  # attention feature expend size
    "data_path": "/data2/Ming/SEED5/FSL/4s/",
    "shots": 1
}

MPED_config = {
    "dataset_name": "MPED",
    # "session": 1,
    "num_class": 7,
    "sup_node_num": 5, #辅助的特征的虚拟节点数量
    "epsilon": 0.05,
    "eeg_node_num": 62,
    "input_size": 5,
    "location_size": 3,
    "expand_size": 10,   # attention feature expend size
    "data_path": "/data2/EEG_data/MPED/MM_Normalized/",
}