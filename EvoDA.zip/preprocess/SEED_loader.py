#-------------------------------------
# SEED 数据的预处理代码 并将SEED的数据打包到npy文件中
# Date: 2023.11.2
# Author: Ming Jin
# All Rights Reserved
#-------------------------------------


import os
import pickle

import numpy as np
from scipy.io import loadmat
import einops
import torch
import random


def resave_data_FSL_4s(data_path, resave_data_path):
    """
    读取数据，并将数据组织成dict封装的list返回
    :param resave_data_path: download data
    :param data_path: reorganized data
    :return:
    """
    for subject in os.listdir(data_path):
        # dic = load_data(os.path.join(raw_data, str(subject)), "de_LDS")
        frequency = "de_LDS"
        data_list = []
        label_list = []
        trial_length_list = []
        dic = {} # 封装数据，标签及每个trial的长度

        emotion = [2, 1, 0, 0, 1, 2, 0, 1, 2, 2, 1, 0, 1, 2, 0] #情绪标签序列，每一个mat文件的情绪标签顺序相同

        for i in range(15):
            data_key = frequency + str(i+1) #读取的数据对应的Key

            meta_data = np.array((loadmat(data_path+str(subject), verify_compressed_data_integrity=False)[data_key])).astype('float')

            meta_data = einops.rearrange(meta_data, 'w h c -> h w c') #(235,62,5)
            trial_length = meta_data.shape[0]  # 读取每一个trial的时间量（非固定值）

            meta_data = extend_normal(meta_data)

            trial_length_list.append(trial_length)
            label_list.append([emotion[i]] * trial_length)

            data_list.append(meta_data)

        dic["data"] = data_list
        dic["label"] = label_list
        dic["trial"] = trial_length_list

        subject = str(subject).strip(".mat")
        np.save(os.path.join(resave_data_path, (str(subject) + ".npy")), dic)




def resave_data_1s(raw_data_path):
    """
    读取按秒封装的数据，并返回dict
    路径为：/data2/EEG_data/SEED/SEED_Multimodal/Chinese/02-EEG-DE-feature/eeg_used_1s/
    :param raw_data_path: 数据的地址，仅包含DE数据
    :return:
    """

    data_list = os.listdir(raw_data_path)
    data_list.sort()

    x_list, y_list, subject_list = [], [], []
    data_dic = {}
    for item in data_list:
        print(item)
        item_data = np.load(os.path.join(raw_data_path, item))

        train_data = pickle.loads(item_data["train_data"])
        train_data_all_fre = []
        for _, value in train_data.items():
            train_data_all_fre.append(value)
        np_train_data = np.array(train_data_all_fre)
        np_train_data = einops.rearrange(np_train_data, 'w h c -> h c w')

        train_label = item_data["train_label"]

        test_data = pickle.loads(item_data["test_data"])
        test_data_all_fre = []
        for _, value in test_data.items():
            test_data_all_fre.append(value)
        np_test_data = np.array(test_data_all_fre)
        np_test_data = einops.rearrange(np_test_data, 'w h c -> h c w')

        test_label = item_data["test_label"]

        data = {"tr_data": np_train_data,
                "tr_label": train_label,
                "ts_data": np_test_data,
                "ts_label": test_label}

        data_dic[str(item)] = data
    return data_dic


def extend_normal(sample):
    """
    对训练集和测试集进行归一化
    :param sample:
    :return:
    """
    for i in range(len(sample)):

        features_min = np.min(sample[i])
        features_max = np.max(sample[i])
        sample[i] = (sample[i] - features_min) / (features_max - features_min)
    return sample


def return_coordinates():

    m1 = [(-2.285379, 10.372299, 4.564709),
          (0.687462, 10.931931, 4.452579),
          (3.874373, 9.896583, 4.368097),
          (-2.82271, 9.895013, 6.833403),
          (4.143959, 9.607678, 7.067061),

          (-6.417786, 6.362997, 4.476012),
          (-5.745505, 7.282387, 6.764246),
          (-4.248579, 7.990933, 8.73188),
          (-2.046628, 8.049909, 10.162745),
          (0.716282, 7.836015, 10.88362),
          (3.193455, 7.889754, 10.312743),
          (5.337832, 7.691511, 8.678795),
          (6.842302, 6.643506, 6.300108),
          (7.197982, 5.671902, 4.245699),

          (-7.326021, 3.749974, 4.734323),
          (-6.882368, 4.211114, 7.939393),
          (-4.837038, 4.672796, 10.955297),
          (-2.677567, 4.478631, 12.365311),
          (0.455027, 4.186858, 13.104445),
          (3.654295, 4.254963, 12.205945),
          (5.863695, 4.275586, 10.714709),
          (7.610693, 3.851083, 7.604854),
          (7.821661, 3.18878, 4.400032),

          (-7.640498, 0.756314, 4.967095),
          (-7.230136, 0.725585, 8.331517),
          (-5.748005, 0.480691, 11.193904),
          (-3.009834, 0.621885, 13.441012),
          (0.341982, 0.449246, 13.839247),
          (3.62126, 0.31676, 13.082255),
          (6.418348, 0.200262, 11.178412),
          (7.743287, 0.254288, 8.143276),
          (8.214926, 0.533799, 4.980188),

          (-7.794727, -1.924366, 4.686678),
          (-7.103159, -2.735806, 7.908936),
          (-5.549734, -3.131109, 10.995642),
          (-3.111164, -3.281632, 12.904391),
          (-0.072857, -3.405421, 13.509398),
          (3.044321, -3.820854, 12.781214),
          (5.712892, -3.643826, 10.907982),
          (7.304755, -3.111501, 7.913397),
          (7.92715, -2.443219, 4.673271),

          (-7.161848, -4.799244, 4.411572),
          (-6.375708, -5.683398, 7.142764),
          (-5.117089, -6.324777, 9.046002),
          (-2.8246, -6.605847, 10.717917),
          (-0.19569, -6.696784, 11.505725),
          (2.396374, -7.077637, 10.585553),
          (4.802065, -6.824497, 8.991351),
          (6.172683, -6.209247, 7.028114),
          (7.187716, -4.954237, 4.477674),

          (-5.894369, -6.974203, 4.318362),
          (-5.037746, -7.566237, 6.585544),
          (-2.544662, -8.415612, 7.820205),
          (-0.339835, -8.716856, 8.249729),
          (2.201964, -8.66148, 7.796194),
          (4.491326, -8.16103, 6.387415),
          (5.766648, -7.498684, 4.546538),

          (-6.387065, -5.755497, 1.886141),
          (-3.542601, -8.904578, 4.214279),
          (-0.080624, -9.660508, 4.670766),
          (3.050584, -9.25965, 4.194428),
          (6.192229, -6.797348, 2.355135),
          ]

    m1 = (m1 - np.min(m1)) / (np.max(m1) - np.min(m1))
    m1 = np.float32(np.array(m1))
    return m1


if __name__ == "__main__":
    # 1. 将下载好的数据重新保存，初次使用时运行
    data_path = "/data2/EEG_data/SEED/SEED_EEG/ExtractedFeatures/"
    processed_data_path = "/data2/Ming/SEED/FSL/4s/"
    if not os.path.exists(processed_data_path):
        os.makedirs(processed_data_path)

    resave_data_FSL_4s(data_path, processed_data_path)



