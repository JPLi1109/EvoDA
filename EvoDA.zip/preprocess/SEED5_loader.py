#-------------------------------------
# SEED 数据的预处理代码 并将SEED的数据打包到npy文件中
# 将SEED-V的数据存储为SEED相同的格式，方便后续的调用
# Date: 2022.11.2
# Author: Ming Jin
# All Rights Reserved
#-------------------------------------


import os
import numpy as np
from scipy.io import loadmat
import einops
import torch
import random
import pickle
from sklearn import svm
# from einops import rearrange, reduce, repeat



def load_data_3fold(data_path):

    clip1 = None
    clip2 = None

    emotionData = np.array([])  # 存储每一个subject的数组
    emotionLabel = np.array([])

    data = np.load(data_path)
    X = pickle.loads(data['data'])
    y = pickle.loads(data['label'])

    x_fold1 = np.array([])
    y_fold1 = np.array([])

    x_fold2 = np.array([])
    y_fold2 = np.array([])

    x_fold3 = np.array([])
    y_fold3 = np.array([])

    for i in range(45):

        metaData = np.array(X[i])
        metaLabel = np.array(y[i])
        metaLabel = metaLabel.astype(int)

        if i%15 in [0, 1, 2, 3, 4]:
            if x_fold1.shape[0] == 0:
                x_fold1 = metaData
                y_fold1 = metaLabel
            else:
                x_fold1 = np.append(x_fold1, metaData, axis=0)
                y_fold1 = np.append(y_fold1, metaLabel, axis=0)

        if i%15 in [5, 6, 7, 8, 9]:
            if x_fold2.shape[0] == 0:
                x_fold2 = metaData
                y_fold2 = metaLabel
            else:
                x_fold2 = np.append(x_fold2, metaData, axis=0)
                y_fold2 = np.append(y_fold2, metaLabel, axis=0)

        if i%15 in [10, 11, 12, 13, 14]:
            if x_fold3.shape[0] == 0:
                x_fold3 = metaData
                y_fold3 = metaLabel
            else:
                x_fold3 = np.append(x_fold3, metaData, axis=0)
                y_fold3 = np.append(y_fold3, metaLabel, axis=0)

    clip1 = y_fold1.size
    clip2 = y_fold1.size + y_fold2.size

    emotionData = np.append(x_fold1, x_fold2, axis=0)
    emotionLabel = np.append(y_fold1, y_fold2, axis=0)
    emotionData = np.append(emotionData, x_fold3, axis=0)
    emotionLabel = np.append(emotionLabel, y_fold3, axis=0)


    return emotionData, emotionLabel, clip1, clip2


def eeg_eye_data_3fold():
    """
    讲脑电数据与眼动数据组织到一个向量中，方便后续的处理
    将重新组织的数据保存成npy格式，方便后续的使用
    :return:
    """
    eegData = "/data2/EEG_data/SEED5/EEG_DE_features/"
    eyeData = "/data2/EEG_data/SEED5/Eye_movement_features/"

    normalizedData = "/data2/EEG_data/SEED5/3fold_multimodal/" # 存储合并的两种数据
    # session = "3"  # or 2,3
    x_list, y_list, subject_list = [], [], []

    for subject in os.listdir(eegData):
        x_eeg, y_eeg, clip1, clip2 = load_data_3fold(os.path.join(eegData, str(subject)))
        # x_eeg = extend_normal(x_eeg)

        # 加入眼动数据，并将eeg和eye数据整合到一起
        x_eye, y_eye, eyeclip1, eyeclip2 = load_data_3fold(os.path.join(eyeData, str(subject)))
        x_eye_log = np.log(x_eye+1) # 先按对数归一化，降低数据间的差异
        # x_eye = extend_normal(x_eye_log)

        assert y_eeg.all() == y_eye.all() # 判断两组数据一一对应

        x_ = np.append(x_eeg, x_eye_log, axis=1)

        x_ = extend_normal(x_)

        # 将预处理文件保存到字典中，方便下次使用时直接加载
        normalizedDataPath = os.path.join(normalizedData)
        dict = {'sample': x_, 'label': y_eeg, 'clip1': clip1, 'clip2':clip2}
        np.save(os.path.join(normalizedDataPath, (str(subject) + ".npy")), dict)

        # # 读取保存好的EEG数据
        # dict_load = np.load(os.path.join(normalizedDataPath,(str(subject)+".npy")), allow_pickle=True)
        # sample_ = dict_load[()]['sample']
        # label_ = dict_load[()]['label']
        #
        #
        # x_list.append(x_)
        # y_list.append(y_)
        # subject_list.append(str(subject))


########################################################
####### 取随机数
########################################################
def random_1D_seed(num):

    rand_lists = []
    for index in range(num):
        grand_list = [i for i in range(62)]
        random.shuffle(grand_list)
        rand_tensor = torch.tensor(grand_list).view(1, 62)
        rand_lists.append(rand_tensor)

    rand_torch = torch.cat(tuple(rand_lists), 0)
    return rand_torch

def extend_normal(sample):
    """
    对训练集和测试集进行归一化
    对于EEG和aux数据进行分开归一化，考虑到两种数据存在较大差异
    :param sample:
    :return:
    """
    for i in range(len(sample)):

        EEG_features_min = np.min(sample[i][:310])
        EEG_features_max = np.max(sample[i][:310])

        aux_features_min = np.min(sample[i][310:])
        aux_features_max = np.max(sample[i][310:])

        sample[i][:310] = (sample[i][:310] - EEG_features_min) / (EEG_features_max - EEG_features_min)
        sample[i][310:] = (sample[i][310:] - aux_features_min) / (aux_features_max - aux_features_min)

    return sample


def extend_normal(sample):
    """
    对训练集和测试集进行归一化
    :param sample:
    :return:
    """
    for i in range(len(sample)):
        features_min = np.min(sample[i])
        features_max = np.max(sample[i])
        sample[i] = (sample[i] - features_min) / (features_max - features_min)
    return sample


def resave_data_FSL_4s_seed5(data_path, resave_data_path):
    """
    读取数据，并将数据组织成dict封装的list返回
    :param resave_data_path: download data
    :param data_path: reorganized data
    :return:
    """
    for subject in os.listdir(data_path):
        # dic = load_data(os.path.join(raw_data, str(subject)), "de_LDS")
        data = np.load(os.path.join(data_path, subject))
        X = pickle.loads(data['data'])
        y = pickle.loads(data['label'])

        dic1, dic2, dic3 = {}, {}, {}

        subject = str(subject).strip(".npz")
        X_normal = []
        y_normal = []

        for i in range(45):
            sub_data = X[i]
            sub_data = extend_normal(sub_data)
            sub_data = einops.rearrange(sub_data, 'w (h c) -> w h c', c = 5)
            X_normal.append(sub_data)

            sub_label = y[i]
            sub_label = sub_label.astype(int)
            y_normal.append(sub_label)

        x_se1 = X_normal[:15]
        x_se2 = X_normal[15:30]
        x_se3 = X_normal[30:]

        y_se1 = y_normal[:15]
        y_se2 = y_normal[15:30]
        y_se3 = y_normal[30:]

        dic1["data"] = x_se1
        dic1["label"] = y_se1
        np.save(os.path.join(resave_data_path, (str(subject) + "1.npy")), dic1)

        dic2["data"] = x_se2
        dic2["label"] = y_se2
        np.save(os.path.join(resave_data_path, (str(subject) + "2.npy")), dic2)

        dic3["data"] = x_se3
        dic3["label"] = y_se3
        np.save(os.path.join(resave_data_path, (str(subject) + "3.npy")), dic3)


if __name__ == "__main__":
    data_path = "/data2/EEG_data/SEED5/EEG_DE_features/"
    processed_data_path = "/data2/Ming/SEED5/FSL/4s/"

    if not os.path.exists(processed_data_path):
        os.makedirs(processed_data_path)

    resave_data_FSL_4s_seed5(data_path, processed_data_path)

    # eeg_eye_data_3fold()



