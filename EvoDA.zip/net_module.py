# -------------------------------------
# encoder的小模块
# Date: 2023.12.6
# Author: Ming Jin
# All Rights Reserved
# -------------------------------------


import torch.nn as nn
import torch
import math
import numpy as np
from einops import rearrange
import copy
from sklearn.metrics import mutual_info_score
from torch import Tensor

from torch_geometric.nn.inits import glorot, zeros
from torch_geometric.typing import (Adj, Size, OptTensor, PairTensor)
from typing import Union, Tuple, Optional
from torch_sparse import SparseTensor, set_diag
from torch_geometric.utils import remove_self_loops, add_self_loops, softmax

import preprocess.SEED_loader as SEED_loader
import torchvision.models as models


class RelationAwareness(nn.Module):
    def __init__(self, args):
        super(RelationAwareness, self).__init__()

        self.args = args
        self.heads = self.args.config["head_size"]

        self.loca_embd = nn.Linear(self.args.config["loca_size"], self.heads*self.args.config["expand_size"]) # 将绝对位置扩增为[62, 6*10]
        self.data_embd = nn.Linear(self.args.config["input_size"], self.heads*self.args.config["expand_size"]) # 将输入的特征扩增为[batch_size, 62, 6*10]
        self.a = nn.Parameter(torch.empty(size=(2*self.args.config["expand_size"], 1)))
        nn.init.xavier_uniform_(self.a.data, gain=1.414)

        self.location = torch.from_numpy(SEED_loader.return_coordinates()).to(self.args.device)

        self.relu = nn.ReLU()

    def forward(self, feature):
        feature = self.relu(self.data_embd(feature)+self.loca_embd(self.location))
        # 在每一个batch都重新构建电极的随机排列
        # 还可以在模型初始化时构建电极排列，保持在整个模型的训练过程中保持不变
        rand_idx = self.pole_random(self.args.rand_num, feature.size(1))
        x_list = []
        # 按随机排列重新处理特征和位置,并计算注意力
        for index in range(rand_idx.size(0)):
            x_random = feature[:, rand_idx[index], :]
            x_1d = rearrange(x_random, "b n (h d) -> b h n d", h=self.heads)
            x_2d = self.cal_att_matrix(x_1d)
            x_list.append(x_2d)
        x = torch.cat(tuple(x_list), 1) # [batch_size, 12, 62, 62]
        return x


    def cal_att_matrix(self, feature):
        data = []
        batch_size, head,  N = feature.size(0), feature.size(1), feature.size(2)
        Wh1 = torch.matmul(feature, self.a[:self.args.config["expand_size"], :])
        Wh2 = torch.matmul(feature, self.a[self.args.config["expand_size"]:, :])
        # broadcast add
        Wh2_T = rearrange(Wh2, "b n h d -> b n d h")
        e = Wh1 + Wh2_T

        return e

    def pole_random(self, rand_num, pole_num):
        """
        生成指定数量的随机排列
        :param rand_num: 需要的随机排列的数量
        :param pole_num: 电极数量
        :return:
        """
        rand_lists = []
        for index in range(rand_num):
            grand_list = [i for i in range(pole_num)]
            np.random.shuffle(grand_list)
            rand_tensor = torch.tensor(grand_list).view(1, 62)
            rand_lists.append(rand_tensor)

        rand_torch = torch.cat(tuple(rand_lists), 0)
        return rand_torch




class ConvNet(nn.Module):
    def __init__(self, emb_size, args, cifar_flag=False):
        super(ConvNet, self).__init__()
        # set size
        self.hidden = 128
        self.last_hidden = self.hidden * 9 if not cifar_flag else self.hidden
        # self.last_hidden = self.hidden * 1 if not cifar_flag else self.hidden
        self.emb_size = emb_size
        self.args = args

        # set layers
        self.conv_1 = nn.Sequential(nn.Conv2d(in_channels=12,
                                              out_channels=self.hidden,
                                              kernel_size=3,
                                              padding=1,
                                              bias=False),
                                    nn.BatchNorm2d(num_features=self.hidden),
                                    nn.MaxPool2d(kernel_size=2),
                                    nn.LeakyReLU(negative_slope=0.2, inplace=True))
        self.conv_2 = nn.Sequential(nn.Conv2d(in_channels=self.hidden,
                                              out_channels=int(self.hidden*1.5),
                                              kernel_size=3,
                                              bias=False),
                                    nn.BatchNorm2d(num_features=int(self.hidden*1.5)),
                                    nn.MaxPool2d(kernel_size=2),
                                    nn.LeakyReLU(negative_slope=0.2, inplace=True))
        self.conv_3 = nn.Sequential(nn.Conv2d(in_channels=int(self.hidden*1.5),
                                              out_channels=self.hidden*2,
                                              kernel_size=3,
                                              padding=1,
                                              bias=False),
                                    nn.BatchNorm2d(num_features=self.hidden * 2),
                                    nn.MaxPool2d(kernel_size=2),
                                    nn.LeakyReLU(negative_slope=0.2, inplace=True),
                                    nn.Dropout2d(0.4))
        self.max = nn.MaxPool2d(kernel_size=2)

        self.conv_4 = nn.Sequential(nn.Conv2d(in_channels=self.hidden*2,
                                              out_channels=self.hidden*4,
                                              kernel_size=3,
                                              padding=1,
                                              bias=False),
                                    nn.BatchNorm2d(num_features=self.hidden * 4),
                                    nn.MaxPool2d(kernel_size=2),
                                    nn.LeakyReLU(negative_slope=0.2, inplace=True),
                                    nn.Dropout2d(0.5))
        self.layer_second = nn.Sequential(nn.Linear(in_features=self.last_hidden * 2 ,
                                                    out_features=self.emb_size, bias=True),
                                          nn.BatchNorm1d(self.emb_size))
        self.layer_last = nn.Sequential(nn.Linear(in_features=self.last_hidden * 4 ,
                                                  out_features=self.emb_size, bias=True),
                                        nn.BatchNorm1d(self.emb_size))

    def forward(self, input_data):
        out_1 = self.conv_1(input_data)
        out_2 = self.conv_2(out_1)
        out_3 = self.conv_3(out_2)
        output_data = self.conv_4(out_3)
        output_data0 = self.max(out_3)
        out1 = self.layer_last(output_data.view(output_data.size(0), -1))
        out2 = self.layer_second(output_data0.view(output_data0.size(0), -1))
        out = torch.cat((out1, out2), dim=1)  # (batch_size, 256)
        return out


class ResNet50(nn.Module):
    def __init__(self):
        super(ResNet50, self).__init__()
        self.resnet50 = models.resnet50(pretrained=True)
        self.resnet50.conv1 = nn.Conv2d(12, 64, kernel_size=7, stride=2, padding=3,
                                   bias=False)
        self.resnet50.fc = nn.Linear(2048, 512)

    def forward(self, x):
        x = self.resnet50(x)
        return x


class ResNet18(nn.Module):
    def __init__(self):
        super(ResNet18, self).__init__()
        self.resnet18 = models.resnet18(pretrained=True)
        self.resnet18.conv1 = nn.Conv2d(12, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.resnet18.fc = nn.Linear(512, 512)
        self.dropout = nn.Dropout(0.4)

    def forward(self, x):
        x = self.resnet18(x)
        x = self.dropout(x)
        return x


