
# -------------------------------------
# 运行跨session的相关实验
# Date: 2023.11.27
# Author: Ming Jin
# All Rights Reserved
# -------------------------------------

import imp
import logging
import os
import argparse
from collections import OrderedDict

import numpy as np
import torch
import random
import datetime
import itertools
import torchnet as tnt
from torch import optim
from torch.autograd import Variable
from tqdm import tqdm
from torch.utils.data import TensorDataset, DataLoader, SequentialSampler
from torch.optim.lr_scheduler import StepLR

from model import EncoderNet, MetaLearner, RelationNet
from utils import *
from dataloader import SEED, SEED5
from config import load_config
from fsl_loader import *


class TrainTest(object):
    def __init__(self, args, log, checkpoint):
        self.args = args
        self.log = log
        self.n_shots = self.args.config["shots"]
        self.n_cls = self.args.config["num_class"]
        self.n_qry = self.args.config["n_qry"]
        self.batch_size = (self.n_qry + self.n_shots) * self.n_cls
        self.checkpoint = checkpoint
        self.meta_lr = self.args.lr  # 在进行meta learning时，使用小lr进行微调

    def train(self, tr_data, tr_label, val_data, val_label):
        # 加载模型配置
        encoder = EncoderNet(self.args).to(self.args.device)
        learner = MetaLearner().to(self.args.device)
        relation = RelationNet().to(self.args.device)

        mse_loss = nn.MSELoss().to(self.args.device)

        optimizer_enc = optim.Adam(encoder.parameters(), lr=self.args.lr)  # 定义encoder的优化器
        scheduler_enc = StepLR(optimizer_enc, step_size=50, gamma=0.5)  # 学习率梯度衰减

        optimizer_len = optim.Adam(learner.parameters(), lr=self.args.lr)  # 定义learner的优化器
        scheduler_len = StepLR(optimizer_len, step_size=50, gamma=0.5)  # 学习率梯度衰减

        optimizer_rel = optim.Adam(relation.parameters(), lr=self.args.lr)  # 定义relation的优化器
        scheduler_rel = StepLR(optimizer_rel, step_size=50, gamma=0.5)  # 学习率梯度衰减

        # 在每个epoch中，随机选择3个类别，进行fsl学习，包含200个episode
        best_val_acc = 0
        best_val_loss = 1000
        for epoch in range(self.args.epoch):
            scheduler_enc.step()
            scheduler_len.step()
            scheduler_rel.step()
            tr_acc, tr_loss, tr_f1, val_acc, val_loss, val_f1 = 0, 0, 0, 0, 0, 0
            l_tr_pred, l_tr_truth, l_val_pred, l_val_truth = [], [], [], []

            tr_data_epoch, tr_label_epoch = rel_n_way_n_shot_loader(tr_data, tr_label, self.n_shots, self.n_cls, self.n_qry,
                                                                    self.args.episode)
            train_data_set = TensorDataset(torch.from_numpy(np.array(tr_data_epoch)).float(),
                                           torch.from_numpy(np.array(tr_label_epoch)).long())
            index_list = list(range(len(tr_data_epoch)))
            seq_sampler = SequentialSampler(index_list)
            tr_loader = DataLoader(train_data_set, sampler=seq_sampler, batch_size=self.batch_size, shuffle=False,
                                   drop_last=False)

            encoder.train()
            learner.train()
            relation.train()
            for i, (data, label) in enumerate(tr_loader, 0):
                optimizer_enc.zero_grad()
                optimizer_len.zero_grad()
                optimizer_rel.zero_grad()

                spt_num = self.n_cls * self.n_shots
                qry_num = self.n_cls * self.n_qry

                y_spt = label[:spt_num]
                y_qry = label[spt_num:]
                x_spt = data[:spt_num].to(self.args.device)
                x_qry = data[spt_num:].to(self.args.device)

                y_cal = y_qry.to(self.args.device, dtype=torch.int64)  # 用于计算acc
                y = torch.zeros(qry_num, self.n_cls).scatter_(1, y_qry.view(-1, 1), 1).to(self.args.device,
                                                                                          dtype=torch.float)

                x_spt = learner(encoder(x_spt))
                x_qry = learner(encoder(x_qry))

                if self.n_shots > 1:
                    x_spt = x_spt.view(self.n_cls, self.n_shots, 128)
                    x_spt = torch.sum(x_spt, 1).squeeze(1)

                x_spt_ext = x_spt.unsqueeze(0).repeat(qry_num, 1, 1)
                x_qry_ext = x_qry.unsqueeze(0).repeat(self.n_cls, 1, 1)
                x_qry_ext = torch.transpose(x_qry_ext, 0, 1)

                x_relation = torch.cat((x_spt_ext, x_qry_ext), 2).view(-1, 256)
                x_relation = relation(x_relation).view(-1, self.n_cls)

                loss = mse_loss(x_relation, y)

                loss.backward()

                optimizer_rel.step()
                optimizer_len.step()
                optimizer_enc.step()

                _, pred = torch.max(x_relation.data, 1)
                tr_loss += loss.data * qry_num  # 将加权的loss相加
                l_tr_pred.extend(pred.data.tolist())
                l_tr_truth.extend(y_cal.data.tolist())

            ##### 将source的数据按照时间的顺序分别采样，采样之后就不再使用新的数据用于评估

            val_data_epoch, val_label_epoch = rel_n_way_n_shot_loader(val_data, val_label, self.n_shots, self.n_cls, self.n_qry,
                                                                      self.args.episode)
            val_data_set = TensorDataset(torch.from_numpy(np.array(val_data_epoch)).float(),
                                         torch.from_numpy(np.array(val_label_epoch)).long())
            index_list_val = list(range(len(val_data_epoch)))
            seq_sampler_val = SequentialSampler(index_list_val)
            val_loader = DataLoader(val_data_set, sampler=seq_sampler_val, batch_size=self.batch_size, shuffle=False,
                                    drop_last=False)

            optimizer_enc.zero_grad()
            optimizer_len.zero_grad()
            optimizer_rel.zero_grad()
            # for name, para in encoder.named_parameters():
            #     para.requires_grad = False

            encoder.eval()
            learner.eval()
            relation.eval()
            for i, (data, label) in enumerate(val_loader, 0):
                with torch.no_grad():
                    spt_num = self.n_cls * self.n_shots
                    qry_num = self.n_cls * self.n_qry

                    y_spt = label[:spt_num]
                    y_qry = label[spt_num:]
                    x_spt = data[:spt_num].to(self.args.device)
                    x_qry = data[spt_num:].to(self.args.device)

                    y_cal = y_qry.to(self.args.device, dtype=torch.int64)  # 用于计算acc
                    y = torch.zeros(qry_num, self.n_cls).scatter_(1, y_qry.view(-1, 1), 1).to(self.args.device,
                                                                                              dtype=torch.float)
                    x_spt = learner(encoder(x_spt))
                    x_qry = learner(encoder(x_qry))

                    if self.n_shots > 1:
                        x_spt = x_spt.view(self.n_cls, self.n_shots, 128)
                        x_spt = torch.sum(x_spt, 1).squeeze(1)

                    x_spt_ext = x_spt.unsqueeze(0).repeat(qry_num, 1, 1)
                    x_qry_ext = x_qry.unsqueeze(0).repeat(self.n_cls, 1, 1)
                    x_qry_ext = torch.transpose(x_qry_ext, 0, 1)

                    x_relation = torch.cat((x_spt_ext, x_qry_ext), 2).view(-1, 256)
                    x_relation = relation(x_relation).view(-1, self.n_cls)

                    loss = mse_loss(x_relation, y)

                    _, pred = torch.max(x_relation.data, 1)
                    val_loss += loss.data * qry_num  # 将加权的loss相加
                    l_val_pred.extend(pred.data.tolist())
                    l_val_truth.extend(y_cal.data.tolist())

            tr_acc, tr_f1 = acc_f1(l_tr_pred, l_tr_truth)
            val_acc, val_f1 = acc_f1(l_val_pred, l_val_truth)
            val_loss = round(float(val_loss / (self.n_cls * self.n_qry * self.args.episode)), 4)
            tr_loss = round(float(tr_loss / (self.n_cls * self.n_qry * self.args.episode)), 4)

            # 在后段，根据更好的loss和更好的acc保存模型保存模型
            if epoch >= int(self.args.epoch / 3):
                if best_val_acc <= val_acc:
                    self.log.info(f"Best acc updated from {best_val_acc} to {val_acc}.")
                    best_val_acc = val_acc

                    if os.path.exists(self.checkpoint):
                        os.remove(self.checkpoint)
                    state = {'encoder': encoder.state_dict(),
                             'learner': learner.state_dict(),
                             'relation': relation.state_dict()}
                    torch.save({
                        "iteration": epoch,
                        "model_state_dict": state,
                        "val_acc": best_val_acc}, self.checkpoint)

            if epoch % 5 == 0:
                self.log.info(
                    f"Epoch: {epoch}, train_acc: {tr_acc}, train_loss: {tr_loss}, train_f1:{tr_f1}, val_acc: {val_acc}, val_loss: {val_loss}, val_f1:{val_f1}")



    def test(self, tr_data, tr_label, ts_data, ts_label):

        ts_data_epoch, ts_label_epoch = rel_n_way_n_shot_loader(ts_data, ts_label, self.n_shots, self.n_cls, self.n_qry,
                                                                self.args.episode)
        ts_data_set = TensorDataset(torch.from_numpy(np.array(ts_data_epoch)).float(),
                                    torch.from_numpy(np.array(ts_label_epoch)).long())
        index_list_ts = list(range(len(ts_data_epoch)))
        seq_sampler_ts = SequentialSampler(index_list_ts)
        ts_loader = DataLoader(ts_data_set, sampler=seq_sampler_ts, batch_size=self.batch_size, shuffle=False,
                               drop_last=False)

        # 加载模型配置
        encoder = EncoderNet(self.args).to(self.args.device)
        learner = MetaLearner().to(self.args.device)
        relation = RelationNet().to(self.args.device)

        mse_loss = nn.MSELoss().to(self.args.device)

        encoder.load_state_dict(torch.load(self.checkpoint)["model_state_dict"]["encoder"])
        learner.load_state_dict(torch.load(self.checkpoint)["model_state_dict"]["learner"])
        relation.load_state_dict(torch.load(self.checkpoint)["model_state_dict"]["relation"])

        ts_acc, ts_loss, ts_f1 = 0, 0, 0
        l_ts_pred, l_ts_truth = [], []

        for i, (data, label) in enumerate(ts_loader, 0):
            # optimizer_cls = optim.Adam(cls.parameters(), lr=self.args.lr)  # 定义training的优化器
            # 1. meta-training
            # meta_weight = self.meta_ada(sur_data_np, data_label, encoder, cls)

            # 2. meta-testing
            with torch.no_grad():
                spt_num = self.n_cls * self.n_shots
                qry_num = self.n_cls * self.n_qry

                y_spt = label[:spt_num]
                y_qry = label[spt_num:]
                x_spt = data[:spt_num].to(self.args.device)
                x_qry = data[spt_num:].to(self.args.device)

                y_cal = y_qry.to(self.args.device, dtype=torch.int64)  # 用于计算acc
                y = torch.zeros(qry_num, self.n_cls).scatter_(1, y_qry.view(-1, 1), 1).to(self.args.device,
                                                                                          dtype=torch.float)
                x_spt = learner(encoder(x_spt))
                x_qry = learner(encoder(x_qry))

                if self.n_shots > 1:
                    x_spt = x_spt.view(self.n_cls, self.n_shots, 128)
                    x_spt = torch.sum(x_spt, 1).squeeze(1)

                x_spt_ext = x_spt.unsqueeze(0).repeat(qry_num, 1, 1)
                x_qry_ext = x_qry.unsqueeze(0).repeat(self.n_cls, 1, 1)
                x_qry_ext = torch.transpose(x_qry_ext, 0, 1)

                x_relation = torch.cat((x_spt_ext, x_qry_ext), 2).view(-1, 256)
                x_relation = relation(x_relation).view(-1, self.n_cls)

                loss = mse_loss(x_relation, y)

                _, pred = torch.max(x_relation.data, 1)
                ts_loss += loss.data * qry_num  # 将加权的loss相加
                l_ts_pred.extend(pred.data.tolist())
                l_ts_truth.extend(y_cal.data.tolist())

        ts_acc, ts_f1 = acc_f1(l_ts_pred, l_ts_truth)
        ts_loss = round(float(ts_loss / (self.n_cls * self.n_qry * self.args.episode)), 4)

        # 测试完删除模型，降低空间占用
        # os.remove(self.checkpoint)
        return ts_acc, ts_f1, ts_loss


    # def meta_test(self, tr_data, tr_label, ts_data, ts_label):
    #
    #     ##############################################################
    #     ########## meta fast adaption
    #     ##############################################################
    #     # 随机采样出source数据池
    #     sur_data_np = source_loader(tr_data, self.classes, 50)
    #     sur_data = torch.tensor(sur_data_np)
    #
    #     ts_data_label_list = n_way_1_shot_loader(ts_data, ts_label, self.classes, self.n_qry,
    #                                               self.args.episode)
    #     ts_data_label_list = tnt.dataset.ListDataset(ts_data_label_list)
    #     ts_loader = ts_data_label_list.parallel(batch_size=self.batch_size, shuffle=True)
    #
    #     # 加载模型配置
    #     encoder = EncoderNet(self.args).to(self.args.device)
    #     cls = ClsLearner().to(self.args.device)
    #     _loss = CE_Label_Smooth_Loss(classes=self.classes,
    #                                  epsilon=self.args.config["epsilon"]).to(self.args.device)
    #     encoder.load_state_dict(torch.load(self.checkpoint)["model_state_dict"]["encoder"])
    #     cls.load_state_dict(torch.load(self.checkpoint)["model_state_dict"]["cls"])
    #
    #     ts_acc, ts_loss, ts_f1 = 0, 0, 0
    #     l_ts_pred, l_ts_truth = [], []
    #
    #     for i, data_label in enumerate(ts_loader, 0):
    #
    #
    #         # optimizer_cls = optim.Adam(cls.parameters(), lr=self.args.lr)  # 定义training的优化器
    #         # 1. meta-training
    #         # meta_weight = self.meta_ada(sur_data_np, data_label, encoder, cls)
    #
    #         # 2. meta-testing
    #         with torch.no_grad():
    #             labels = torch.unsqueeze(data_label[0], 1)
    #             datas = data_label[1:]
    #             x = torch.cat(datas).float().to(self.args.device)
    #             y = labels.to(self.args.device, dtype=torch.int64)
    #             x = cls(encoder(x))
    #
    #             x = torch.split(x, self.batch_size, 0)
    #             cos_dist_list = [[] for _ in range(self.classes)]
    #             for idx in range(self.classes):
    #                 dist1 = x[-1].div(torch.norm(x[-1], p=2, dim=1, keepdim=True).expand_as(x[-1]))
    #                 dist2 = x[idx].div(torch.norm(x[idx], p=2, dim=1, keepdim=True).expand_as(x[idx]))
    #                 cos_dist_list[idx] = 50 * torch.sum(torch.mul(dist1, dist2), dim=1, keepdim=True)
    #             cos_dist_all = torch.cat(cos_dist_list, 1)
    #
    #             y = y.squeeze(1)
    #             loss = _loss(cos_dist_all, y)
    #
    #             _, pred = torch.max(cos_dist_all.data, 1)
    #             ts_loss += loss.data * y.shape[0]  # 将加权的loss相加
    #             l_ts_pred.extend(pred.data.tolist())
    #             l_ts_truth.extend(y.data.tolist())
    #
    #     ts_acc, ts_f1 = acc_f1(l_ts_pred, l_ts_truth)
    #     ts_loss = round(float(ts_loss / len(ts_data_label_list)), 4)
    #
    #     # 测试完删除模型，降低空间占用
    #     # os.remove(self.checkpoint)
    #     return ts_acc, ts_f1, ts_loss
    #

    def meta_ada(self, sur_data, batch_tar_data, encoder, cls):
        """
        传入数据和模型，计算出快速适应的权重
        :param sur_data:
        :param batch_tar_data:
        :param encoder_net:
        :param cls_net:
        :return:
        """


        x_t_qry = batch_tar_data[int(self.classes) + 1]  # 获取所有的query数据

        # 获取到spt数据后对其增广和随机排列，
        x_t_T = list(zip(*batch_tar_data))
        x_t_spt = torch.tensor([item.cpu().detach().numpy() for item in x_t_T[0][1:-1]])
        x_t_spt = x_t_spt.unsqueeze(0).repeat(int(x_t_qry.shape[0]/self.classes),1,1,1)
        x_t_spt = x_t_spt.reshape(-1, *x_t_spt.shape[2:])
        indice_t = torch.randperm(x_t_spt.size(0))
        x_t_spt = x_t_spt[indice_t]

        x_tar = torch.cat([x_t_spt, x_t_qry], dim=0)  # 获取当前batch的所有source数据：batch_size
        x_tar = x_tar.float().to(self.args.device)
        meta_loss = [0 for _ in range(self.args.inner_loop+5)]

        for i_task in range(1):

            data_num = x_tar.shape[0] // 2 # 选取前一半的数据用于inner loop
            indice_s = torch.randperm(x_tar.size(0))
            x_sur = torch.tensor(sur_data[i_task][indice_s])

            fast_weight = cls.parameters() #在每个task中，都使用之前的权重，评估每一个task的loss

            x_sur = x_sur.float().to(self.args.device)

            for item in range(3):
                emb_s_spt = cls.forward(encoder(x_sur[:data_num]), fast_weight, bn_training=True)
                emb_t_spt = cls.forward(encoder(x_tar[:data_num]), fast_weight, bn_training=True)
                spt_loss = mmd_rbf_noaccelerate(emb_s_spt, emb_t_spt)

                inner_grad = torch.autograd.grad(spt_loss, fast_weight, create_graph=True)
                fast_weight = list(map(lambda p: p[1] - self.meta_lr * p[0], zip(inner_grad, fast_weight)))

                emb_s_qry = cls.forward(encoder(x_sur[data_num:]), fast_weight, bn_training=True)
                emb_t_qry = cls.forward(encoder(x_tar[data_num:]), fast_weight, bn_training=True)
                qry_loss = mmd_rbf_noaccelerate(emb_s_qry, emb_t_qry)

                meta_loss[item] += qry_loss

        loss_mean = meta_loss[7] / 1
        # meta_weight_ = cls.parameters()
        meta_weight = cls.parameters()
        outer_grad = torch.autograd.grad(loss_mean, meta_weight)
        meta_weight = list(map(lambda p: p[1] - self.meta_lr*5 * p[0], zip(outer_grad, meta_weight)))
        # optimizer.zero_grad()
        # loss_mean.backward()
        # optimizer.step()

        # meta_weight = cls.parameters()
        return meta_weight


class INTER:
    """运行跨session的实验，将3个session分别用于训练，验证和测试"""
    def __init__(self, args, log):
        self.args = args
        self.log = log
        self.classes = self.args.config["num_class"]
        self.batch_size = self.args.config["batch_size"]
        self.all_data = load_data_FSL_4s(self.args.config["data_path"])  # 获取所有实验数据
        self.subject_num = self.args.config["subject_num"]

        # 初始化dataloader
        self.dataset_loader = None  # 预先声明一下实验数据
        if self.args.dataset == "SEED":
            self.dataset_loader = SEED(self.all_data)
        elif self.args.dataset == "SEED5":
            self.dataset_loader = SEED5(self.all_data)


    # inter subject on SEED dataset
    def seed(self):
        all_dic = {}
        for session_idx in range(3):

            acc_dic, f1_dic = {}, {}  # 收集每一个被试的测试结果
            for subject_index in range(self.subject_num):
            # self.log.info(f'Start inter subject training on subject_{str(subject_index)}.')
            # 将数据封装为cross session的专有形式
                self.log.info(f'Start inter subject training on subject_{str(subject_index)} session_{str(session_idx)}.')

                # 根据是否是测试选择不同的checkpoint
                if self.args.is_test:
                    checkpoint = os.path.join('/data2/Ming/log/EDA_BCI/model-backup/seed-cse-1shot-match/8084/', str(subject_index) + "_best_model.pth.tar")
                else:
                    checkpoint = os.path.join(self.args.log_dir, str(subject_index)+"_session_"+ str(session_idx) + "_best_model.pth.tar")

                inter_data = self.dataset_loader.inter_subject(subject_index, self.subject_num, "se"+str(session_idx+1))

                train_test = TrainTest(self.args, self.log, checkpoint)

                # FSL train and test
                train_test.train(inter_data["tr_data"], inter_data["tr_label"], inter_data["val_data"], inter_data["val_label"])
                ts_acc, ts_f1, ts_loss = train_test.test(inter_data["tr_data"], inter_data["tr_label"],inter_data["ts_data"], inter_data["ts_label"])

                # # for meta test
                # ts_acc, ts_f1, ts_loss = train_test.meta_test(inter_data["tr_data"], inter_data["tr_label"],
                #                                      inter_data["ts_data"], inter_data["ts_label"])

                self.log.info(f"Subject{subject_index + 1}, test_acc: {ts_acc}, test_f1: {ts_f1}, test_loss: {ts_loss}")
                acc_dic[str(subject_index)] = ts_acc
                f1_dic[str(subject_index)] = ts_f1

                self.log.info(f'Average acc:{round(np.mean(list(acc_dic.values())), 4)}, '
                              f'acc_std: {round(np.std(list(acc_dic.values())), 4)}, '
                              f'f1: {round(np.mean(list(f1_dic.values())), 4)}, '
                              f'and f1_std: {round(np.std(list(f1_dic.values())), 4)}')

            print(acc_dic)
        all_dic[("session"+str(session_idx))] = acc_dic
        print(all_dic)

    def seed5(self):
        all_dic = {}
        for session_idx in range(3):

            acc_dic, f1_dic = {}, {}  # 收集每一个被试的测试结果
            for subject_index in range(self.subject_num):
                # self.log.info(f'Start inter subject training on subject_{str(subject_index)}.')
                # 将数据封装为cross session的专有形式
                self.log.info(
                    f'Start inter subject training on subject_{str(subject_index)} session_{str(session_idx)}.')

                # 根据是否是测试选择不同的checkpoint
                if self.args.is_test:
                    checkpoint = os.path.join('/data2/Ming/log/EDA_BCI/model-backup/seed-cse-1shot-match/8084/',
                                              str(subject_index) + "_best_model.pth.tar")
                else:
                    checkpoint = os.path.join(self.args.log_dir, str(subject_index) + "_session_" + str(
                        session_idx) + "_best_model.pth.tar")

                inter_data = self.dataset_loader.inter_subject(subject_index, self.subject_num,
                                                               "se" + str(session_idx + 1))

                train_test = TrainTest(self.args, self.log, checkpoint)

                # FSL train and test
                train_test.train(inter_data["tr_data"], inter_data["tr_label"], inter_data["val_data"],
                                 inter_data["val_label"])

                ts_acc, ts_f1, ts_loss = train_test.test(inter_data["tr_data"], inter_data["tr_label"],inter_data["ts_data"], inter_data["ts_label"])

                # # for meta test
                # ts_acc, ts_f1, ts_loss = train_test.meta_test(inter_data["tr_data"], inter_data["tr_label"],
                #                                      inter_data["ts_data"], inter_data["ts_label"])

                self.log.info(f"Subject{subject_index + 1}, test_acc: {ts_acc}, test_f1: {ts_f1}, test_loss: {ts_loss}")
                acc_dic[str(subject_index)] = ts_acc
                f1_dic[str(subject_index)] = ts_f1

                self.log.info(f'Average acc:{round(np.mean(list(acc_dic.values())), 4)}, '
                              f'acc_std: {round(np.std(list(acc_dic.values())), 4)}, '
                              f'f1: {round(np.mean(list(f1_dic.values())), 4)}, '
                              f'and f1_std: {round(np.std(list(f1_dic.values())), 4)}')

            self.log.info(acc_dic)
            all_dic[("session" + str(session_idx))] = acc_dic
        self.log.info(all_dic)