import os
import logging
import torch
import shutil
import datetime
import torch.nn as nn
from torch.nn import functional as F
import numpy as np




class CE_Label_Smooth_Loss(nn.Module):
    def __init__(self, classes=4, epsilon=0.14, ):
        super(CE_Label_Smooth_Loss, self).__init__()
        self.classes = classes
        self.epsilon = epsilon

    def forward(self, input, target):
        log_prob = F.log_softmax(input, dim=-1)
        weight = input.new_ones(input.size()) * \
                 self.epsilon / (input.size(-1) - 1.)
        weight.scatter_(-1, target.unsqueeze(-1), (1. - self.epsilon))
        loss = (-weight * log_prob).sum(dim=-1).mean()
        return loss

def load_data_FSL_4s(data_path):
    # 一次性读取所有被试的数据
    all_data = {}
    for subject in os.listdir(data_path):

        dict_load = np.load(os.path.join(data_path, str(subject)), allow_pickle=True)
        subject = str(subject).strip(".npy")

        all_data[subject] = dict_load
    return all_data

def set_logging_config(logdir):
    """
    logging configuration
    :param logdir:
    :return:
    """
    def beijing(sec, what):
        beijing_time = datetime.datetime.now() + datetime.timedelta(hours=8)
        return beijing_time.timetuple()

    if not os.path.exists(logdir):
        os.makedirs(logdir)

    logging.Formatter.converter = beijing
    logging.basicConfig(format="[%(asctime)s] [%(name)s] %(message)s",
                        level=logging.INFO,
                        handlers=[logging.FileHandler(os.path.join(logdir, ("log.txt"))),
                                  logging.StreamHandler(os.sys.stdout)])


from sklearn.metrics import confusion_matrix, accuracy_score, f1_score
def acc_f1(y_pred, y_truth):
    acc = accuracy_score(y_truth, y_pred)
    f1 = f1_score(y_truth, y_pred, average="macro")
    return round(acc, 4), round(f1, 4)


def save_checkpoint(state, is_best, exp_name):
    """
    save the checkpoint during training stage
    :param state: content to be saved
    :param is_best: if model's performance is the best at current step
    :param exp_name: experiment name
    :return: None
    """
    torch.save(state, os.path.join(f'{exp_name}', 'checkpoint.pth.tar'))


# ## for dependent experiment
# def cse_train_test_split(all_data, subject_idx):
#     """
#     返回对应被试的数据，共分为4个不同的划分：1-2，1-3，2-3，12-3
#     该方法对于SEED，SEED4和SEED5均通用
#     :param all_data:
#     :param subject_idx:
#     :return:
#     """
#
#     data_dic = {}
#     subject_dic = {}
#     trial = []
#
#     if subject_idx <= 9:
#         subject_idx = (str(subject_idx) + "_")
#     for subject in all_data:
#         if str(subject)[:2] == str(subject_idx):
#             # subject_dic[str(subject).replace("_", ".")] = all_data[subject]
#             subject_dic[subject] = all_data[subject]
#
#     key_idx = list(sorted(subject_dic.keys()))
#
#     for i in range(len(key_idx)):
#         data = "se" + str(i+1) + "_data"
#         label = "se" + str(i + 1) + "_label"
#         data_dic[data] = subject_dic[str(key_idx[i])][()]["data"]
#         data_dic[label] = subject_dic[str(key_idx[i])][()]["label"]
#         trial.append(subject_dic[key_idx[i]][()]["trial"])
#
#     data_dic["trial"] = trial
#     return data_dic


## for dependent experiment
def de_train_test_split_3fold(data, label, index1, index2, config):

    x_train = np.array([])
    x_test = np.array([])
    y_train = np.array([])
    y_test = np.array([])

    if str(config["dataset_name"]) == "SEED5":
        new_data = split_eye_data(data, config["sup_node_num"])


    x1 = new_data[:index1]
    x2 = new_data[index1:index2]
    x3 = new_data[index2:]

    y1 = label[:index1]
    y2 = label[index1:index2]
    y3 = label[index2:]

    if config["cfold"] == 1:
        x_train = np.append(x2, x3, axis=0)
        x_test = x1
        y_train = np.append(y2, y3, axis=0)
        y_test = y1

    elif config["cfold"] == 2:
        x_train = np.append(x1, x3, axis=0)
        x_test = x2
        y_train = np.append(y1, y3, axis=0)
        y_test = y2

    else:
        x_train = np.append(x1, x2, axis=0)
        x_test = x3
        y_train = np.append(y1, y2, axis=0)
        y_test = y3


    data_and_label = {"x_train": x_train,
                      "x_test": x_test,
                      "y_train": y_train,
                      "y_test": y_test}

    return data_and_label


## for independent experiment
def inde_train_test_split(dataList, labelList, subject_index, config):

    x_train, x_test, y_train, y_test = np.array([]), np.array([]),\
                                       np.array([]), np.array([])

    for j in range(len(dataList)):
        if j == subject_index:
            x_test = dataList[j]
            y_test = labelList[j]
        else:
            if x_train.shape[0] == 0:
                x_train = dataList[j]
                y_train = labelList[j]
            else:
                x_train = np.append(x_train, dataList[j], axis=0)
                y_train = np.append(y_train, labelList[j], axis=0)

    if str(config["dataset_name"]) == "SEED5":
        x_train = split_eye_data(x_train, config["sup_node_num"])
        x_test = split_eye_data(x_test, config["sup_node_num"])
    elif str(config["dataset_name"]) == "MPED":
        x_train = split_eye_data(x_train, config["sup_node_num"])
        x_test = split_eye_data(x_test, config["sup_node_num"])

    data_and_label = {"x_train": x_train,
                      "x_test": x_test,
                      "y_train": y_train,
                      "y_test": y_test}

    return data_and_label


## for independent experiment
def transfer_train_test_split(dataList, labelList, dataList_tar, labelList_tar, index, config):

    x_train, x_test, y_train, y_test = np.array([]), np.array([]),\
                                       np.array([]), np.array([])


    x_train = dataList[index]
    y_train = labelList[index]
    x_test = dataList_tar[index]
    y_test = labelList_tar[index]

    # 在数据中插入零
    x_train = split_eye_data(x_train, config["sup_node_num"])
    x_test = split_eye_data(x_test, config["sup_node_num"])


    data_and_label = {"x_train": x_train,
                      "x_test": x_test,
                      "y_train": y_train,
                      "y_test": y_test}

    return data_and_label

#
# def guassian_kernel(source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
#     n_samples = int(source.size()[0]) + int(target.size()[0])
#     total = torch.cat([source, target], dim=0)
#     total0 = total.unsqueeze(0).expand(int(total.size(0)), int(total.size(0)), int(total.size(1)))
#     total1 = total.unsqueeze(1).expand(int(total.size(0)), int(total.size(0)), int(total.size(1)))
#     L2_distance = ((total0 - total1) ** 2).sum(2)
#     if fix_sigma:
#         bandwidth = fix_sigma
#     else:
#         bandwidth = torch.sum(L2_distance.data) / (n_samples ** 2 - n_samples)
#     bandwidth /= kernel_mul ** (kernel_num // 2)
#     bandwidth_list = [bandwidth * (kernel_mul ** i) for i in range(kernel_num)]
#     kernel_val = [torch.exp(-L2_distance / bandwidth_temp) for bandwidth_temp in bandwidth_list]
#     return sum(kernel_val)  # /len(kernel_val)
#
#
# def DAN(source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
#     bs_s = source.shape[0]
#     bs_t = target.shape[0]
#
#     k_mat = guassian_kernel(source, target,
#                             kernel_mul=kernel_mul, kernel_num=kernel_num, fix_sigma=fix_sigma)
#
#     loss = torch.abs((torch.sum(k_mat[0:bs_s, 0:bs_s]) - torch.sum(torch.diagonal(k_mat[0:bs_s, 0:bs_s]))) / bs_s / (bs_s - 1) + (
#                 torch.sum(k_mat[bs_t:bs_s + bs_t, bs_t:bs_s + bs_t]) - torch.sum(
#             torch.diagonal(k_mat[bs_t:bs_s + bs_t, bs_t:bs_s + bs_t]))) / bs_t / (bs_t - 1) - torch.sum(
#         k_mat[0:bs_s, bs_t:bs_s + bs_t]) / bs_s / bs_t * 2)
#     return loss


def guassian_kernel(source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
    n_samples = int(source.size()[0])+int(target.size()[0])
    total = torch.cat([source, target], dim=0)
    total0 = total.unsqueeze(0).expand(int(total.size(0)), int(total.size(0)), int(total.size(1)))
    total1 = total.unsqueeze(1).expand(int(total.size(0)), int(total.size(0)), int(total.size(1)))
    L2_distance = ((total0-total1)**2).sum(2)
    if fix_sigma:
        bandwidth = fix_sigma
    else:
        bandwidth = torch.sum(L2_distance.data) / (n_samples**2-n_samples)
    bandwidth /= kernel_mul ** (kernel_num // 2)
    bandwidth_list = [bandwidth * (kernel_mul**i) for i in range(kernel_num)]
    kernel_val = [torch.exp(-L2_distance / bandwidth_temp) for bandwidth_temp in bandwidth_list]
    return sum(kernel_val)#/len(kernel_val)


# def mmd_rbf_accelerate(source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
#     batch_size = int(source.size()[0])
#     kernels = guassian_kernel(source, target,
#         kernel_mul=kernel_mul, kernel_num=kernel_num, fix_sigma=fix_sigma)
#     loss = 0
#     for i in range(batch_size):
#         s1, s2 = i, (i+1)%batch_size
#         t1, t2 = s1+batch_size, s2+batch_size
#         loss += kernels[s1, s2] + kernels[t1, t2]
#         loss -= kernels[s1, t2] + kernels[s2, t1]
#     return loss / float(batch_size)


def mmd_rbf_noaccelerate(source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
    batch_size = int(source.size()[0])
    kernels = guassian_kernel(source, target,
                              kernel_mul=kernel_mul, kernel_num=kernel_num, fix_sigma=fix_sigma)
    XX = kernels[:batch_size, :batch_size]
    YY = kernels[batch_size:, batch_size:]
    XY = kernels[:batch_size, batch_size:]
    YX = kernels[batch_size:, :batch_size]
    loss = torch.mean(XX + YY - XY -YX)
    return loss


