# -------------------------------------
# 模型的主框架
# Date: 2023.11.24
# Author: Ming Jin
# All Rights Reserved
# -------------------------------------

import torch.nn as nn
import torch
import math
import numpy as np
from einops import rearrange
import copy
from sklearn.metrics import mutual_info_score
from torch import Tensor
from torch.nn import functional as F

from torch_geometric.nn.inits import glorot, zeros
from torch_geometric.typing import (Adj, Size, OptTensor, PairTensor)
from typing import Union, Tuple, Optional
from torch_sparse import SparseTensor, set_diag
from torch_geometric.utils import remove_self_loops, add_self_loops, softmax

import preprocess.SEED_loader as SEED_pre
import torchvision.models as models
from net_module import RelationAwareness, ResNet18, ResNet50, ConvNet


class EncoderNet(nn.Module):
    def __init__(self, args):
        super(EncoderNet, self).__init__()
        self.args = args

        self.location_em = nn.Linear(4, 10)  # 将绝对位置扩增为[62, 6*10]

        self.relationAwareness = RelationAwareness(args=self.args)

        self.resnet_embed = 256
        self.backbone_output = self.resnet_embed * 2

        self.convNet = ConvNet(self.resnet_embed, args=self.args)
        # self.resNet50_pretrain = ResNet50()
        # self.resNet18_pretrain = ResNet18()

        self.l_relu = nn.LeakyReLU(0.1)
        self.bn = nn.BatchNorm1d(self.backbone_output)
        self.bn_2D = nn.BatchNorm2d(12)

    def forward(self, x):
        x = self.relationAwareness(x)
        x_ = self.bn_2D(x)

        output = None
        # if self.args.backbone == "ConvNet":
        output = self.convNet(x_)  # (batch_size, 512) #ConvNet
        # elif self.args.backbone == "ResNet18":
        #     output = self.resNet18_pretrain(x_)
        # elif self.args.backbone == "ResNet50":
        #     output = self.resNet50_pretrain(x_)

        return output


class MetaLearner(nn.Module):
    def __init__(self):
        super(MetaLearner, self).__init__()
        self.component = [
            ('dropout', [0.4]),
            ('linear', [512, 512]),
            ('leakyrelu', [0.1]),
            ('bn', [512]),
            ('linear', [128, 512]),
        ]
        # this dict contains all tensors needed to be optimized
        self.vars = nn.ParameterList()
        # running_mean and running_var
        self.vars_bn = nn.ParameterList()

        for i, (name, param) in enumerate(self.component):
            if name is 'linear':
                w = nn.Parameter(torch.ones(*param))
                torch.nn.init.kaiming_normal_(w)
                self.vars.append(w)
                self.vars.append(nn.Parameter(torch.zeros(param[0])))

            elif name is 'bn':
                w = nn.Parameter(torch.ones(param[0]))
                self.vars.append(w)
                self.vars.append(nn.Parameter(torch.zeros(param[0])))

                running_mean = nn.Parameter(torch.zeros(param[0]), requires_grad=False)
                running_var = nn.Parameter(torch.ones(param[0]), requires_grad=False)
                self.vars_bn.extend([running_mean, running_var])

            elif name in ['tanh', 'relu', 'avg_pool2d', 'max_pool2d',
                          'flatten', 'reshape', 'leakyrelu', 'sigmoid', 'dropout']:
                continue
            else:
                raise NotImplementedError

    def extra_repr(self):
        info = ''
        for name, param in self.component:
            if name is 'linear':
                tmp = 'linear:(in:%d, out:%d)'%(param[1], param[0])
                info += tmp + '\n'
            elif name is 'leakyrelu':
                tmp = 'leakyrelu:(slope:%f)'%(param[0])
                info += tmp + '\n'
            elif name is 'avg_pool2d':
                tmp = 'avg_pool2d:(k:%d, stride:%d, padding:%d)'%(param[0], param[1], param[2])
                info += tmp + '\n'
            elif name in ['flatten', 'dropout', 'tanh', 'relu', 'upsample', 'reshape', 'sigmoid', 'use_logits', 'bn']:
                tmp = name + ':' + str(tuple(param))
                info += tmp + '\n'
            else:
                raise NotImplementedError
        return info

    def forward(self, x, vars=None, bn_training=True):
        if vars is None:
            vars = self.vars

        idx = 0
        bn_idx = 0

        for name, param in self.component:
            if name == 'linear':
                w, b = vars[idx], vars[idx+1]
                x = F.linear(x, w, b)
                idx += 2
            elif name == 'bn':
                w, b = vars[idx], vars[idx+1]
                running_mean, running_var = self.vars_bn[bn_idx], self.vars_bn[bn_idx+1]
                x = F.batch_norm(x, running_mean, running_var, weight=w, bias=b, training=bn_training)
                idx += 2
                bn_idx += 2
            elif name == 'leakyrelu':
                x = F.leaky_relu(x, negative_slope=param[0])
            elif name == 'dropout':
                x = F.dropout(x, p=param[0])
            else:
                raise NotImplementedError

        assert idx == len(vars)
        assert bn_idx == len(self.vars_bn)
        return x

    def zero_grad(self, vars=None):
        with torch.no_grad():
            if vars is None:
                for p in self.vars:
                    if p.grad is not None:
                        p.grad.zero_()
            else:
                for p in vars:
                    if p.grad is not None:
                        p.grad.zero_()

    def parameters(self):
        """
        override this function since initial parameters will return with a generator.
        """
        return self.vars


class RelationNet(nn.Module):
    def __init__(self):
        super(RelationNet, self).__init__()
        self.dropout = nn.Dropout(0.5)
        self.l_relu = nn.LeakyReLU(0.1)
        self.mlp_0 = nn.Linear(256, 128)
        self.bn = nn.BatchNorm1d(128)
        self.mlp_1 = nn.Linear(128, 32)
        self.mlp_2 = nn.Linear(32, 1)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                m.bias.data = torch.ones(m.bias.data.size())
            elif isinstance(m, nn.BatchNorm1d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()


    def forward(self, feature):
        x = self.dropout(feature)
        x = self.l_relu(self.mlp_0(x))
        x = self.bn(x)
        x = self.l_relu(self.mlp_1(x))
        # x = self.dropout(x)
        x = torch.sigmoid(self.mlp_2(x))
        return x

# def weights_init(m):
#     classname = m.__class__.__name__
#     if classname.find('BatchNorm') != -1:
#         m.weight.data.fill_(1)
#         m.bias.data.zero_()
#     elif classname.find('Linear') != -1:
#         n = m.weight.size(1)
#         m.weight.data.normal_(0, 0.01)
#         m.bias.data = torch.ones(m.bias.data.size())
