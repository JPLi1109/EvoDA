import os
import random
import numpy as np

# from utils import cse_train_test_split


class SEED:

    def __init__(self, all_data):
        self.all_data = all_data

    def intra_subject(self, subject_idx):
        """
        对于cse任务，将不同的session分别用于训练，验证和测试
        :param subject_idx:
        :return:
        """
        data_dic = {}
        subject_dic = {}
        trial = []

        if subject_idx <= 9:
            subject_idx = (str(subject_idx) + "_")
        for subject in self.all_data:
            if str(subject)[:2] == str(subject_idx):
                # subject_dic[str(subject).replace("_", ".")] = all_data[subject]
                subject_dic[subject] = self.all_data[subject]

        key_idx = list(sorted(subject_dic.keys()))

        for i in range(len(key_idx)):
            data = "se" + str(i + 1) + "_data"
            label = "se" + str(i + 1) + "_label"
            data_dic[data] = subject_dic[str(key_idx[i])][()]["data"]
            data_dic[label] = subject_dic[str(key_idx[i])][()]["label"]
            trial.append(subject_dic[key_idx[i]][()]["trial"])

        data_dic["trial"] = trial
        subject_data = data_dic

        cse_data = {"tr_data": subject_data["se1_data"], "tr_label": subject_data["se1_label"],
                    "val_data": subject_data["se2_data"], "val_label": subject_data["se2_label"],
                    "ts_data": subject_data["se3_data"], "ts_label": subject_data["se3_label"]}

        return cse_data

    def inter_subject(self, subject_idx, subject_num, session):
        # 将所有被试的数据根据不同的session进行封装
        all_data = {}
        for item in range(subject_num):
            data_dic = {}
            subject_dic = {}
            trial = []
            cur_item = None # 当前被试

            if item < 9:
                cur_item = str(item+1)+"_"
            else:
                cur_item = str(item+1)

            for subject in self.all_data:
                if str(subject)[:2] == str(cur_item):
                    subject_dic[str(subject)] = self.all_data[subject]

            key_idx = list(sorted(subject_dic.keys()))

            for i in range(len(key_idx)):
                data = "se" + str(i + 1) + "_data"
                label = "se" + str(i + 1) + "_label"
                data_dic[data] = subject_dic[str(key_idx[i])][()]["data"]
                data_dic[label] = subject_dic[str(key_idx[i])][()]["label"]
                trial.append(subject_dic[key_idx[i]][()]["trial"])

            all_data[str(item+1)] = data_dic

        datas, labels = self.merge_trial(all_data, session)
        all_data = self.inter_train_test_split(subject_idx, datas, labels, subject_num)
        return all_data


    def inter_train_test_split(self, subject_index, datas, labels, subject_num):

        # 分离测试数据
        inter_data = {}
        ts_data, ts_label, val_data, val_label, tr_data, tr_label = [], [], [], [], [], []

        ts_data = datas[subject_index*3:(subject_index+1)*3]
        ts_label = labels[subject_index*3:(subject_index+1)*3]
        del datas[subject_index*3:(subject_index+1)*3]
        del labels[subject_index*3:(subject_index+1)*3]

        # 随机选取验证数据
        sample = [i for i in range(subject_num-1)]
        rand_sample = random.sample(sample, 2)
        rand_sample = rand_sample[::-1]  # 将数据倒序后避免删除数据时发生错误

        val_data.append(datas[rand_sample[0]*3:(rand_sample[0]+1)*3])
        val_label.append(labels[rand_sample[0]*3:(rand_sample[0]+1)*3])
        val_data.append(datas[rand_sample[1] * 3:(rand_sample[1] + 1) * 3])
        val_label.append(labels[rand_sample[1] * 3:(rand_sample[1] + 1) * 3])

        del datas[rand_sample[0]*3:(rand_sample[0]+1)*3]
        del labels[rand_sample[0]*3:(rand_sample[0]+1)*3]
        del datas[rand_sample[1] * 3:(rand_sample[1] + 1) * 3]
        del labels[rand_sample[1] * 3:(rand_sample[1] + 1) * 3]

        val_data = [token for i in val_data for token in i]
        val_label = [token for i in val_label for token in i]

        inter_data = {"tr_data": datas, "tr_label": labels,
                    "val_data": val_data, "val_label": val_label,
                    "ts_data": ts_data, "ts_label": ts_label}
        return inter_data

    def merge_trial(self, input, session):
        data_key  = str(session)+"_data"
        label_key = str(session)+"_label"
        datas = []
        labels = []
        for i in range(len(input)):
            subject_data = input[str(i+1)]
            data = subject_data[data_key]
            label = subject_data[label_key]
            class1_data, class2_data, class3_data = [], [], []
            class1_label, class2_label, class3_label = [], [], []

            for trial in range(len(label)):

                if label[trial][0] == 0:
                    class1_data.append(data[trial])
                    class1_label.append(label[trial])
                elif label[trial][0] == 1:
                    class2_data.append(data[trial])
                    class2_label.append(label[trial])
                elif label[trial][0] == 2:
                    class3_data.append(data[trial])
                    class3_label.append(label[trial])
                else:
                    raise ValueError

            x_cls1 = [token for i in class1_data for token in i]
            x_cls2 = [token for i in class2_data for token in i]
            x_cls3 = [token for i in class3_data for token in i]
            y_cls1 = [token for i in class1_label for token in i]
            y_cls2 = [token for i in class2_label for token in i]
            y_cls3 = [token for i in class3_label for token in i]

            datas.append(x_cls1)
            datas.append(x_cls2)
            datas.append(x_cls3)
            labels.append(y_cls1)
            labels.append(y_cls2)
            labels.append(y_cls3)

        return datas, labels

    def __getitem__(self, item):
        pass

    def __len__(self):
        pass


class SEED5:

    def __init__(self, all_data):
        self.all_data = all_data

    def intra_subject(self, subject_idx):
        """
        对于cse任务，将不同的session分别用于训练，验证和测试
        :param subject_idx:
        :return:
        """
        data_dic = {}
        subject_dic = {}
        trial = []

        if subject_idx <= 9:
            subject_idx = (str(subject_idx) + "_")
        for subject in self.all_data:
            if str(subject)[:2] == str(subject_idx):
                # subject_dic[str(subject).replace("_", ".")] = all_data[subject]
                subject_dic[subject] = self.all_data[subject]

        key_idx = list(sorted(subject_dic.keys()))

        for i in range(len(key_idx)):
            data = "se" + str(i + 1) + "_data"
            label = "se" + str(i + 1) + "_label"
            data_dic[data] = subject_dic[str(key_idx[i])][()]["data"]
            data_dic[label] = subject_dic[str(key_idx[i])][()]["label"]
            # trial.append(subject_dic[key_idx[i]][()]["trial"])

        # data_dic["trial"] = trial
        subject_data = data_dic

        cse_data = {"tr_data": subject_data["se1_data"], "tr_label": subject_data["se1_label"],
                    "val_data": subject_data["se2_data"], "val_label": subject_data["se2_label"],
                    "ts_data": subject_data["se3_data"], "ts_label": subject_data["se3_label"]}

        return cse_data

    def inter_subject(self, subject_idx, subject_num, session):
        # 将所有被试的数据根据不同的session进行封装
        all_data = {}
        for item in range(subject_num):
            data_dic = {}
            subject_dic = {}
            trial = []
            cur_item = None # 当前被试

            if item < 9:
                cur_item = str(item+1)+"_"
            else:
                cur_item = str(item+1)

            for subject in self.all_data:
                if str(subject)[:2] == str(cur_item):
                    subject_dic[str(subject)] = self.all_data[subject]

            key_idx = list(sorted(subject_dic.keys()))

            for i in range(len(key_idx)):
                data = "se" + str(i + 1) + "_data"
                label = "se" + str(i + 1) + "_label"
                data_dic[data] = subject_dic[str(key_idx[i])][()]["data"]
                data_dic[label] = subject_dic[str(key_idx[i])][()]["label"]
                # trial.append(subject_dic[key_idx[i]][()]["trial"])

            all_data[str(item+1)] = data_dic

        datas, labels = self.merge_trial(all_data, session)
        all_data = self.inter_train_test_split(subject_idx, datas, labels, subject_num)
        return all_data


    def inter_train_test_split(self, subject_index, datas, labels, subject_num):

        # 分离测试数据
        inter_data = {}
        ts_data, ts_label, val_data, val_label, tr_data, tr_label = [], [], [], [], [], []

        ts_data = datas[subject_index*5:(subject_index+1)*5]
        ts_label = labels[subject_index*5:(subject_index+1)*5]
        del datas[subject_index*5:(subject_index+1)*5]
        del labels[subject_index*5:(subject_index+1)*5]

        # 随机选取验证数据
        sample = [i for i in range(subject_num-1)]
        rand_sample = random.sample(sample, 3)
        rand_sample = rand_sample[::-1] # 将数据倒序后避免删除数据时发生错误

        val_data.append(datas[rand_sample[0]*5:(rand_sample[0]+1)*5])
        val_label.append(labels[rand_sample[0]*5:(rand_sample[0]+1)*5])
        val_data.append(datas[rand_sample[1] * 5:(rand_sample[1] + 1) * 5])
        val_label.append(labels[rand_sample[1] * 5:(rand_sample[1] + 1) * 5])
        val_data.append(datas[rand_sample[2] * 5:(rand_sample[2] + 1) * 5])
        val_label.append(labels[rand_sample[2] * 5:(rand_sample[2] + 1) * 5])

        del datas[rand_sample[0]*5:(rand_sample[0]+1)*5]
        del labels[rand_sample[0]*5:(rand_sample[0]+1)*5]
        del datas[rand_sample[1] * 5:(rand_sample[1] + 1) * 5]
        del labels[rand_sample[1] * 5:(rand_sample[1] + 1) * 5]
        del datas[rand_sample[2] * 5:(rand_sample[2] + 1) * 5]
        del labels[rand_sample[2] * 5:(rand_sample[2] + 1) * 5]

        val_data = [token for i in val_data for token in i]
        val_label = [token for i in val_label for token in i]

        inter_data = {"tr_data": datas, "tr_label": labels,
                    "val_data": val_data, "val_label": val_label,
                    "ts_data": ts_data, "ts_label": ts_label}
        return inter_data

    def merge_trial(self, input, session):
        data_key  = str(session)+"_data"
        label_key = str(session)+"_label"
        datas = []
        labels = []
        for i in range(len(input)):
            subject_data = input[str(i+1)]
            data = subject_data[data_key]
            label = subject_data[label_key]
            class1_data, class2_data, class3_data, class4_data, class5_data = [], [], [], [], []
            class1_label, class2_label, class3_label, class4_label, class5_label = [], [], [], [], []

            for trial in range(len(label)):

                if label[trial][0] == 0:
                    class1_data.append(data[trial])
                    class1_label.append(label[trial])
                elif label[trial][0] == 1:
                    class2_data.append(data[trial])
                    class2_label.append(label[trial])
                elif label[trial][0] == 2:
                    class3_data.append(data[trial])
                    class3_label.append(label[trial])
                elif label[trial][0] == 3:
                    class4_data.append(data[trial])
                    class4_label.append(label[trial])
                elif label[trial][0] == 4:
                    class5_data.append(data[trial])
                    class5_label.append(label[trial])
                else:
                    raise ValueError

            x_cls1 = [token for i in class1_data for token in i]
            x_cls2 = [token for i in class2_data for token in i]
            x_cls3 = [token for i in class3_data for token in i]
            x_cls4 = [token for i in class4_data for token in i]
            x_cls5 = [token for i in class5_data for token in i]
            y_cls1 = [token for i in class1_label for token in i]
            y_cls2 = [token for i in class2_label for token in i]
            y_cls3 = [token for i in class3_label for token in i]
            y_cls4 = [token for i in class4_label for token in i]
            y_cls5 = [token for i in class5_label for token in i]

            datas.append(x_cls1)
            datas.append(x_cls2)
            datas.append(x_cls3)
            datas.append(x_cls4)
            datas.append(x_cls5)
            labels.append(y_cls1)
            labels.append(y_cls2)
            labels.append(y_cls3)
            labels.append(y_cls4)
            labels.append(y_cls5)

        return datas, labels

    def __getitem__(self, item):
        pass

    def __len__(self):
        pass

class DataLoader:
    pass



