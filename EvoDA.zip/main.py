# -------------------------------------
# 运行跨session的相关实验
# Date: 2023.12.14
# Author: Ming Jin
# All Rights Reserved
# -------------------------------------

import logging
import os
import argparse
import numpy as np
import torch
import random
import datetime
import torchnet as tnt
from torch import optim
from torch.autograd import Variable
from tqdm import tqdm
from torch.utils.data import TensorDataset, DataLoader

from model import EncoderNet
from utils import *
from config import load_config
from fsl_loader import *
from intra_trainers import INTRA
from inter_trainers import INTER



def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", type=str, default="cuda:9", help="gpu device")
    # parser.add_argument("--checkpoint_dir", type=str, default=os.path.join(".", "checkpoint"), help="")
    parser.add_argument("--num_gpu", type=int, default=1, help="")
    parser.add_argument("--display_step", type=int, default=100, help="")
    parser.add_argument("--log_step", type=int, default=100, help="log information in how many steps")
    parser.add_argument('--save_step', type=int, default=50, help='step size for saving trained models')
    parser.add_argument("--log_dir", type=str, default="/data2/Ming/log/EDA_BCI/relation/", help="log file dir") # 以后将所有工作的LOG文件都放在同一个文件夹下，方便访问和使用
    parser.add_argument("--lr", type=float, default=0.03, help="")
    parser.add_argument("--epoch", type=int, default=100, help="")
    parser.add_argument("--episode", type=int, default=300, help="episode per epoch")
    parser.add_argument("--dataset", type=str, default="SEED5", help="")
    parser.add_argument("--seed", type=int, default=222, help="")
    parser.add_argument("--mode", type=str, default="inter", help="intra or inter mode")
    parser.add_argument("--backbone", type=str, default="REL", help="MAT, REL, PRO")
    # parser.add_argument("--framework", type=str, default="EFA_net", help="")
    parser.add_argument("--rand_num", type=int, default=2, help="")
    parser.add_argument("--inner_loop", type=int, default=4, help="")
    parser.add_argument("--is_test", type=bool, default=False, help="")

    args = parser.parse_args()
    # load config file for different datasets
    args.config = load_config(args.dataset)

    args.exp_name = "{}way_{}shot_{}_{}_{}".format(args.config["num_class"],
                                                args.config["shots"],
                                                args.backbone,
                                                args.dataset,
                                                args.mode)

    datatime_path = str((datetime.datetime.now() + datetime.timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')).replace(" ", "-")
    args.log_dir = os.path.join(args.log_dir, args.exp_name, datatime_path)
    set_logging_config(args.log_dir)
    logger = logging.getLogger("main")

    logger.info("Generated logs and checkpoint will be saved to：{}".format(args.log_dir))
    logger.info(args)

    # set random seed
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    random.seed(args.seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.enabled = False  # 由于环境不匹配后补的代码

    # select trainer for different training mode
    trainer = None
    if args.mode == "intra":
        trainer = INTRA(args, logger)
    else:
        trainer = INTER(args, logger)

    # 根据不同的数据集选择不同的函数加载数据
    if args.dataset == "SEED":
        trainer.seed()
    elif args.dataset == "SEED5":
        trainer.seed5()



if __name__ == "__main__":
    main()
