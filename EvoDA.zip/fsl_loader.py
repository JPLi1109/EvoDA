# -------------------------------------
# 执行few shot 的数据加载和封装
# Date: 2023.12.6
# Author: Ming Jin
# All Rights Reserved
# -------------------------------------

import numpy as np
import random
import einops


# def n_way_1_shot_loader(in_data_list, in_label_list, n_way=3, n_qry=10, n_episode=200):
#     """
#     由于参考的relation net的网络有所不同，使用episode当作batch
#     :param in_data_list: 输入的数据list
#     :param in_label_list: 输入的标签list
#     :param n_way: 需要识别的类别数量
#     :param n_qry: 每次训练时，每个类别的query样本的数量
#     :param n_episode: 每个epoch中所选取的spisode的数量
#     :return: 返回label+spt+qry的zip组合
#     """
#
#     n_length = n_way * n_qry * n_episode
#
#     # 创建 n_way+1 个空list存放spt和qry
#     out_data_lists = [[] for _ in range(n_way + 1)]
#     out_label_list = []
#
#     for idx_episode in range(n_episode):
#
#         # 先为所有的样本选择三个互斥的类别的索引。
#         cls_idx = [-1] * n_way
#         cls_random = np.array(range(len(in_label_list)))
#         np.random.shuffle(cls_random)
#         for i in range(len(in_label_list)):
#             for j in range(len(cls_idx)):
#                 if in_label_list[cls_random[i]][0] == j and cls_idx[j] == -1:
#                     cls_idx[j] = cls_random[i]
#
#         # 每个类随机采数据：n_shot+ n_qry
#         data_all = [[] for _ in range(n_way)]
#         for idx in range(n_way):
#             data_all[idx] = random.sample(list(in_data_list[cls_idx[idx]]), n_qry + 1)
#
#         # 将每个类的最后一个数据作为spt
#         spt_data = []
#         for idx in range(n_way):
#             spt_data.append(data_all[idx][-1])
#
#         # 组装spt数据和qry数据
#         for cls_item in range(n_way):
#             for qry_item in range(n_qry):
#                 current_cls = cls_idx[cls_item]
#
#                 # 写入qry样本
#                 out_data_lists[-1].append(data_all[cls_item][qry_item])
#
#                 # 将每一个qry样本的同标签的spt样本的位置随机化
#                 spt_label_pos = np.random.randint(n_way)
#                 out_label_list.append(spt_label_pos)
#
#                 # 将正确的spt根据索引插入对应位置，并将余下的样本打乱
#                 spt_copy = spt_data[:]
#                 tmp = spt_copy[cls_item]
#                 del spt_copy[cls_item]
#                 np.random.shuffle(spt_copy)
#                 spt_copy.insert(spt_label_pos, tmp)
#
#                 for idx in range(n_way):
#                     out_data_lists[idx].append(spt_copy[idx])
#
#     out_data_label = list(zip(out_label_list, *out_data_lists))
#     np.random.shuffle(out_data_label)
#     # 需要解包两遍才能恢复原来的形状
#     out_data_label_T = list(zip(*out_data_label))
#     out_data_label = list(zip(*out_data_label_T))
#
#     return out_data_label



# 根据设定的batch size的大小进行采样和训练
def rel_n_way_1_shot_loader(in_data_list, in_label_list, n_way=3, n_qry=5, n_episode=200):
    """
    将样本和标签打包成易于fsl训练和测试的形式（cross session）
    :param in_data_list: 输入的数据list
    :param in_label_list: 输入的标签list
    :param n_way: 需要识别的类别数量
    :param n_qry: 每次训练时，每个类别的query样本的数量
    :param n_episode: 每个epoch中所选取的spisode的数量
    :return: 返回label+spt+qry的zip组合
    """

    # n_length = n_way * n_qry * n_episode

    # 创建 n_way+1 个空list存放spt和qry
    out_data_lists = []
    out_label_lists = []

    for idx_episode in range(n_episode):

        # 先为所有的样本选择三个互斥的类别的索引。
        cls_idx = [-1] * n_way
        cls_random = np.array(range(len(in_label_list)))
        np.random.shuffle(cls_random)
        for i in range(len(in_label_list)):
            for j in range(len(cls_idx)):
                if in_label_list[cls_random[i]][0] == j and cls_idx[j] == -1:
                    cls_idx[j] = cls_random[i]

        # 每个类随机采数据：n_shot+ n_qry
        data_all = [[] for _ in range(n_way)]
        for idx in range(n_way):
            data_all[idx] = random.sample(list(in_data_list[cls_idx[idx]]), n_qry + 1)

        # 将每个类的最后一个数据作为spt
        spt_data = []
        for idx in range(n_way):
            spt_data.append(data_all[idx][-1])

        spt_label = [i for i in range(n_way)] # 为数据创建对应的类别标签

        qry_data_ = []
        qry_label_ = []
        for idx in range(n_way):
            qry_data_.extend(data_all[idx][:-1])
            qry_label_.extend([spt_label[idx]]*n_qry)

        index = np.arange((n_way*n_qry))
        np.random.shuffle(index)
        qry_data = [qry_data_[i] for i in index]
        qry_label = [qry_label_[i] for i in index]

        data = spt_data + qry_data
        label = spt_label + qry_label

        out_data_lists.extend(data)
        out_label_lists.extend(label)

    return out_data_lists, out_label_lists


def rel_n_way_n_shot_loader(in_data_list, in_label_list, n_shot=5, n_way=3, n_qry=5, n_episode=200):
    """
    将样本和标签打包成易于fsl训练和测试的形式（cross session）
    :param in_data_list: 输入的数据list
    :param in_label_list: 输入的标签list
    :param n_way: 需要识别的类别数量
    :param n_qry: 每次训练时，每个类别的query样本的数量
    :param n_episode: 每个epoch中所选取的spisode的数量
    :return: 返回label+spt+qry的zip组合
    """

    # n_length = n_way * n_qry * n_episode

    # 创建 n_way+1 个空list存放spt和qry
    out_data_lists = []
    out_label_lists = []

    for idx_episode in range(n_episode):

        # 先为所有的样本选择三个互斥的类别的索引。
        cls_idx = [-1] * n_way
        cls_random = np.array(range(len(in_label_list)))
        np.random.shuffle(cls_random)
        for i in range(len(in_label_list)):
            for j in range(len(cls_idx)):
                if in_label_list[cls_random[i]][0] == j and cls_idx[j] == -1:
                    cls_idx[j] = cls_random[i]

        # 每个类随机采数据：n_shot+ n_qry
        data_all = [[] for _ in range(n_way)]
        for idx in range(n_way):
            data_all[idx] = random.sample(list(in_data_list[cls_idx[idx]]), n_qry + n_shot)

        # 将每个类的最后n个数据作为spt
        spt_data = []
        for idx in range(n_way):
            spt_data.extend(data_all[idx][n_qry:])

        spt_label_ = [i for i in range(n_way) ] # 为数据创建对应的类别标签

        qry_data_ = []
        qry_label_ = []
        for idx in range(n_way):
            qry_data_.extend(data_all[idx][:n_qry])
            qry_label_.extend([spt_label_[idx]]*n_qry)

        index = np.arange((n_way*n_qry))
        np.random.shuffle(index)
        qry_data = [qry_data_[i] for i in index]
        qry_label = [qry_label_[i] for i in index]

        # 将spt的标签复制n_shot倍
        spt_label = [val for val in spt_label_ for i in range(n_shot)]

        data = spt_data + qry_data
        label = spt_label + qry_label

        out_data_lists.extend(data)
        out_label_lists.extend(label)

    return out_data_lists, out_label_lists


def source_loader(in_data_list, n_class, subdata_num=50):
    """
    根据类别的数量将source组装成evolvable的数据流
    :param in_data_list:
    :param n_class:
    :param subdata_num:
    :return:
    """
    x_sur = [[] for _ in range(len(in_data_list))]
    for item in range(len(in_data_list)):
        x_sur[item] = random.sample(list(in_data_list[item]), subdata_num)

    x_sur_np = np.array(x_sur)
    x_sur_np_ = einops.rearrange(x_sur_np, 't n h c -> (t n) h c')
    x_sur_np = einops.rearrange(x_sur_np_, '(t n) h c -> t n h c', t=int(len(x_sur)/n_class))

    return x_sur_np